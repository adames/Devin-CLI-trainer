# Devin Dojo

Run `python3 dojo.py` for the default flashcard, live-drill, and mystery-ticket session.
Use `python3 dojo.py play --mode flash|drill|combo --topic REGEX --rounds N --seed N`.
Add `--no-live` to practice offline; `--allow-credits` enables credit-consuming drills.
Run `python3 dojo.py stats`, `python3 dojo.py list`, or `python3 dojo.py reset`.
Progress is saved under `$DOJO_HOME` or `~/.devin-dojo/`.
Built-in content lives in `content/`; add JSON items with the same schema to `$DOJO_HOME/content/`.
Flashcards come from `../cards.tsv` and the GUIDE-sourced questions are multiple choice.
Live drills use a fresh `$DOJO_HOME/arena/<drill-id>` directory and clean up afterward.
Put `~/.local/bin` on `PATH` if the Devin CLI is installed there.
