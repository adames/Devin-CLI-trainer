# devin-dojo spec (authored by lead; implement exactly)

Goal: ONE terminal game `python3 dojo.py` that combines flashcards, live drills and "combo" mystery tickets
under a single spaced-repetition + XP system. User: a Cognition support engineer learning Devin CLI + general CLI.
Runs on the user's own machine (macOS or Linux; Windows best-effort). Python >= 3.8, stdlib ONLY.

## Layout
```
~/devin-cli-mastery/dojo/
  dojo.py                 # engine + CLI (single entrypoint)
  content/cards.json      # flash items (converted from ../cards.tsv)
  content/drills.json     # live drills
  content/scenarios.json  # combo tickets
  tests/test_dojo.py      # unittest
  README.md               # 20 lines max: how to run, modes, how to add content
```
State: `$DOJO_HOME` or `~/.devin-dojo/` -> `state.json`, arena dirs `arena/<drill-id>/`.
Content is loaded from `content/` next to dojo.py; also merge any `$DOJO_HOME/content/*.json` (user-added items, same schema).

## CLI
```
python3 dojo.py                      # play a session (default plan below)
python3 dojo.py play [--mode flash|drill|combo] [--topic REGEX] [--rounds N] [--seed N] [--no-live] [--allow-credits]
python3 dojo.py stats                # level, xp, streak, accuracy by topic, items per Leitner box, due today
python3 dojo.py list [--type ...]    # list item ids/topics/boxes
python3 dojo.py reset [--yes]
```
All input via input() (works with piped stdin, no raw-key or /dev/tty reads) so tests can drive it.
EOF on stdin = end session gracefully and save. Ctrl-C = save and exit cleanly.
Colors via ANSI; disabled when NO_COLOR set or stdout not a tty.

## Session plan (default)
Warm-up: 6 flash -> 2 drills -> 4 flash -> 1 combo "boss". `--rounds N` caps total rounds (combos count as 1).
If a type has no eligible items (e.g. no live drills available), fill with flash.
Item selection per type: due items first (most overdue first), then new items (max 5 new per session), then
not-due items with lowest box. `--seed` makes shuffles deterministic.

## Spaced repetition (Leitner), per item id
box 1..5; intervals: box1 = requeue later in the same session and due now; box2 1d; box3 3d; box4 7d; box5 21d.
correct -> box+1 (max 5), due = now + interval(new box). wrong -> box 1, due now, and requeue once later this session
(flash only). Track seen/correct/last_seen per item. New items start at box 1.

## Scoring / game feel
- Global streak across rounds: consecutive correct rounds. multiplier = min(1 + 0.25*streak, 3.0). Wrong resets to 0.
- Flash: 10 xp exact/auto-correct; 5 if a hint was used; 5 if self-graded ("count it?").
- Drill: 25 xp + speed bonus (max(0, 15 - seconds//20)).
- Combo: 50 base + 10 per key evidence found + 5 per unused turn, times the in-scenario combo multiplier (see below);
  wrong root-cause guess -20 (min 0 total), then you get the fix question anyway.
- All round xp is multiplied by the global streak multiplier.
- Level = floor(sqrt(xp/50)) + 1. Titles: 1 Intern, 2 Log Reader, 3 Triage Tech, 4 Tracer, 5 Config Whisperer,
  6 Root-Causer, 7+ Staff RCA.
- Daily streak: days in a row with >=1 session.
- Header line each round: `[L3 Triage Tech | 420xp | streak x1.75 | round 4/13 | flash:hooks]`.
- End of session summary: xp gained, accuracy, per-topic accuracy, weakest 3 topics, missed items (question + answer),
  items due tomorrow, best combo.

## Flash items (content/cards.json)
Schema: `{"id","topic","q","answers":[...],"keywords":[...],"hint","explain"}`; optional `"choices":[...]` (MC; answers
then holds the correct choice text; show as a/b/c/d shuffled, accept the letter or the text).
Convert every row of ../cards.tsv (66 rows) — keep q/answer facts EXACTLY; do not invent facts.
- `answers`: canonical answer(s) the user might type (e.g. `devin -p "prompt"` -> ["devin -p", "devin --print"]).
- `keywords`: minimal set of tokens that must ALL appear for auto-correct (e.g. ["-p"] or ["config.local.json"]).
- `topic`: one of launch, sessions, auth, config, permissions, modes, slash, cloud, hooks, rules, skills, mcp, logs,
  debug, acp, general-cli.
- `hint`: first useful fragment; `explain`: the full answer from the TSV.
Grading: normalize (lowercase, strip quotes/backticks, collapse whitespace). Correct if normalized input equals a
normalized answer, OR contains all keywords (case-insensitive substring). Otherwise reveal the answer + explain and ask
"count it? [y/N]" (self-grade). Input `?` = show hint (once), `skip` = wrong without prompt, `quit` = end session.
Also add ~8 MC items for precedence/modes ordering-type questions sourced only from ../GUIDE.md facts.

## Live drills (content/drills.json)
Schema: `{"id","topic","prompt","platforms":["linux","darwin"],"requires":["devin"|"auth"|"strace"|...],
"costs_credits":false,"setup":[shell...],"kind":"answer"|"check","truth":"shell cmd -> stdout","check":"shell cmd -> exit 0",
"cleanup":[shell...],"explain"}`
- All commands run with cwd = arena dir (`$DOJO_HOME/arena/<id>`, recreated fresh each time), env DOJO_ARENA set.
- kind=answer: user types an answer; compare normalized to normalized `truth` stdout (strip). kind=check: user presses
  Enter when done; run `check`; exit 0 = pass. Either way the user may type `!<cmd>` to run a shell command inline
  (cwd=arena, show output), repeatable, before answering. `give up` = wrong, show explain.
- Skip (not eligible) when platform mismatch, required binary missing (shutil.which), `auth` required and
  `devin auth status` output contains "Not logged in", or costs_credits and not --allow-credits, or --no-live.
- ALWAYS run cleanup (finally), including on Ctrl-C.
- Truth/check commands must not need jq (use python3 -c for JSON).
Drills to implement (verify EVERY one against the real CLI on this box; if one doesn't behave as described, fix the
check or drop it and tell me which + why):
1. d-version (devin): "Installed Devin CLI version number?" truth `devin --version | awk '{print $2}'`.
2. d-newest-log (devin): "Filename of the newest Devin CLI log?" truth `ls -t ~/.local/share/devin/cli/logs | head -1`.
3. d-doctor-count (devin): "How many checks does `devin doctor --json` run?" truth via python json len(checks).
4. d-auth (devin): "Is the CLI logged in? yes/no" truth: no if "Not logged in" in `devin auth status` else yes.
5. d-skill (devin): "Create a PROJECT skill named `log-triage` in this arena so `devin skills list` shows it." check:
   `devin skills list` (cwd arena) output contains log-triage. Note: arena may need `git init` to be a project root —
   setup does `git init -q`; verify.
6. d-agents-rule (devin): "Add an always-on project rule via the file the docs recommend." check `devin rules list`
   mentions AGENTS.md (verify what rules list prints; adapt check to the real output).
7. d-hooks (none): "Create a project hooks file with a PreToolUse hook (standalone-file format)." check with python:
   `.devin/hooks.v1.json` parses, has top-level key "PreToolUse", and NO top-level "hooks" key.
8. d-local-deny (none): "Deny `rm` in a personal, gitignored project config." check: `.devin/config.local.json` parses
   and permissions.deny contains an entry containing "Exec(rm".
9. d-mcp-add (devin): "Add a stdio MCP server named dojo-echo that runs `echo hi`." check `devin mcp get dojo-echo`
   exit 0; cleanup `devin mcp remove dojo-echo` (+ whatever scope flag is needed). Find out which file it writes
   (user vs project) — the user's real config must be left exactly as before; if it writes user scope, make setup
   back up ~/.config/devin/mcp_config.json and cleanup restore it.
10. d-session-json (devin): "How many sessions does `devin list --format json` report here?" truth via python len().
11. d-grep-errors (none, general-cli): setup writes app.log (python3 -c, 200 lines, seeded deterministic mix of
    INFO/WARN/ERROR incl. some 'error' lowercase and a gzipped rotated app.log.1.gz); "How many lines contain ERROR
    (case-insensitive) across app.log and app.log.1.gz?" truth computed by python in setup -> written to .truth; truth cmd `cat .truth`.
12. d-bad-json (none, general-cli): setup creates 12 json files in nested dirs, exactly one invalid (random per run);
    "Relative path of the one invalid JSON file?" truth `cat .truth`.
13. d-port (python3, general-cli, linux+darwin): setup starts `python3 -m http.server <random free port>` in background,
    writes pid to .pid and port to .truth; "Which TCP port is the python process in this arena listening on?";
    cleanup kills pid. (ensure it dies even on Ctrl-C.)
14. d-strace-policy (strace, linux): "Using strace on `devin rules list`, what system-wide policy file does the CLI probe?"
    truth `echo /etc/devin/system.json` — verify it's really probed on this box first.
15. d-print-pong (auth, costs_credits): "Use print mode so Devin replies with exactly PONG; type what it printed." truth `echo PONG`.

## Combo tickets (content/scenarios.json)
Faux customer shell. Schema:
```
{"id","topic","title","ticket":"customer message","prompt":"customer@laptop ~/app$ ","turns":8,
 "commands":[{"id","match":["regex",...],"output":"...","evidence":true|false,"source":"recorded"|"simulated"}],
 "unknown_output":"(no useful output)",
 "root_cause":{"q","choices":[4],"answer":idx},"fix":{"q","choices":[4],"answer":idx},
 "optimal":["cmd","cmd",...],"explain":"..."}
```
Loop: show ticket, then prompt. Each typed command costs 1 turn; first matching command entry (regex, case-insensitive,
fullmatch against whitespace-normalized input) prints its output. `source=simulated` outputs get a dim " [sim]" tag.
Unmatched: if first token not in a small known set (devin, cat, ls, jq, rg, grep, env, echo, type, which, command,
bash, curl, ps, lsof, ss, strace, tail, head, find, sqlite3, git, python3, printenv, diff) print
`bash: <tok>: command not found`, else unknown_output. Re-running an already-run command costs a turn but gives no evidence.
In-scenario combo: consecutive NEW evidence commands build combo x1 -> x2 -> x3 (cap); a non-evidence command resets
to x1. Final combo multiplier used in scoring = best combo reached. Meta commands (no turn cost): `ticket` (reprint),
`hint` (reveals next optimal command, -10xp), `solve`, `quit`. Out of turns -> forced solve.
After solve: show correct answers, the optimal chain, explain, and "evidence found k/n".
Correct = root cause right (fix right adds +25). Leitner update on scenario id uses root-cause correctness.

Recorded outputs: where a command is marked RECORD below, reproduce the fault for real on this box in a throwaway
HOME (`HOME=$(mktemp -d)` + PATH incl. the devin binary) and paste the ACTUAL output (trim to <= 15 lines, replace
the temp HOME path with /home/customer). If a RECORD command needs auth, or the real behaviour contradicts the
scenario (e.g. the CLI actually reports the error loudly), tell me in your report — don't invent; mark it simulated only
if I said SIM. Simulated outputs must be plain standard-tool output (bash/ls/cat style), not invented Devin error text.

S1 hooks-wrapper (hooks): ticket "I added a PreToolUse hook in .devin/hooks.v1.json to block rm -rf but it never fires."
  fault: file content `{"hooks":{"PreToolUse":[...valid hook...]}}`.
  cmds: `cat .devin/hooks.v1.json` (evidence, SIM = the file), `devin --version` (SIM "devin 3000.11.3 (9c803229faa4)"),
  `devin doctor` (RECORD in a project dir with that file), `ls -la .devin` (SIM), `python3 -m json.tool .devin/hooks.v1.json`
  / `jq . .devin/hooks.v1.json` (evidence, SIM pretty JSON), `devin rules list` (RECORD).
  Optional: if you can find any CLI command that lists hooks without auth, RECORD it as evidence.
  root cause: the standalone file must BE the hooks object; the "hooks" wrapper key is only for config.json/settings files.
  distractors: hooks need org enablement; event name should be pre_tool_use; hooks only load from ~/.config/devin.
  fix: remove the wrapper so PreToolUse is top-level (or move under "hooks" in .devin/config.json); verify with /hooks.
  distractors: add --sandbox; restart with --permission-mode dangerous; rename file to hooks.json.
S2 path-alias (debug): ticket "Devin keeps saying `node: command not found`, but node works in my terminal."
  cmds (all SIM, realistic bash): `command -v node`/`which node` -> `alias node='~/.nvm/versions/node/v20.11.1/bin/node'`
  (for which: nothing, exit 1), `type node` -> "node is aliased to `~/.nvm/...'" (evidence), `echo $PATH` (no nvm dir),
  `bash -lic 'command -v node'` / `bash -lic "echo $PATH"` (evidence: empty / PATH without nvm),
  `cat ~/.bashrc` / `grep node ~/.bashrc` (evidence: the alias line, no PATH export), `devin --version`.
  root cause: node is only an alias; Devin snapshots env vars from the login shell ($SHELL interactive login) at startup,
  aliases/functions are not exported. distractors: sandbox blocks node; nvm unsupported; PATH too long.
  fix: export PATH (nvm bin dir) in the shell profile, then restart Devin (snapshot is taken once at startup).
  distractors: /clear; devin update; run with --sandbox.
S3 dead-proxy (debug): ticket "Every devin command that hits the network fails on my work laptop since Monday."
  fault: HTTPS_PROXY=http://127.0.0.1:9 (nothing listening).
  cmds: `env | grep -i proxy` / `printenv | grep -i proxy` (evidence, SIM), `curl -sv https://cli.devin.ai -o /dev/null`
  (evidence, RECORD with that env), `devin update` (RECORD with that env — it hits the network without auth; if it
  doesn't, pick another no-auth network command and tell me), the RUST_LOG trace variant of it
  `RUST_LOG=reqwest=trace,hyper=trace CHISEL_LOG_STDERR=1 devin update` (evidence, RECORD, trim to the lines that show
  the proxy/connection error), `devin auth status` (RECORD), `devin --version` (SIM).
  root cause: HTTPS_PROXY points at a proxy that isn't listening; CLI routes its traffic via proxy env vars (system mode).
  distractors: token expired; cli.devin.ai is down; TLS CA missing.
  fix: fix/unset HTTPS_PROXY (or set proxy.mode/url in config.json / NO_PROXY). distractors: reinstall; auth logout/login; --sandbox.
S4 untrusted-print (launch): ticket "`devin -p` works on my laptop but fails in our CI job in a freshly cloned repo."
  cmds: `devin -p "summarize the repo"` (evidence, RECORD in a fresh untrusted dir — needs auth? if it errors before auth
  with the trust message, great; if it only shows a login error, tell me), `devin --version` (SIM), `devin auth status`
  (SIM: logged in), `devin --help | grep -A3 trust` (evidence, RECORD), `ls -la` (SIM).
  root cause: print mode can't show the workspace-trust prompt and fails in an untrusted directory.
  fix: `--respect-workspace-trust false` in CI (or trust the dir first). distractors: set DEVIN_MODEL; use --sandbox; -c.
S5 org-policy (permissions): ticket "I run with --permission-mode dangerous but Devin still asks before every git push. Bug?"
  cmds (SIM): `devin --version`, `cat ~/.config/devin/config.json` (no ask rules), `cat .devin/config.json` (no ask rules),
  `cat .devin/config.local.json` (No such file), `devin doctor` (RECORD normal), `ls ~/.cache/devin` (evidence, SIM:
  include team_settings.bin), `strings ~/.cache/devin/team_settings.bin | grep -i push` (evidence, SIM: a line like
  `Exec(git push)` near `ask`).
  root cause: org/team settings ask rule; org deny/ask rules cannot be overridden by any permission mode or local config.
  distractors: dangerous mode is deprecated; project config overrides CLI flags; smart mode's model judged it unsafe.
  fix: admin changes Team Settings; user can't override locally. distractors: add allow in config.local.json; use /bypass; delete the cache file.
S6 stale-binary (launch): ticket "I ran `devin update` twice and it says I'm on the latest, but `devin --version` still shows an old version."
  cmds: `devin --version` (SIM old: "devin 3000.9.0 (...)" use a plausible short hash), `type -a devin` / `which -a devin`
  (evidence, SIM: /usr/local/bin/devin then /home/customer/.local/bin/devin), `echo $PATH` (evidence, /usr/local/bin first),
  `~/.local/bin/devin --version` (evidence, SIM "devin 3000.11.3 (9c803229faa4)"), `ls ~/.local/share/devin/cli/_versions`
  (RECORD from this box, path-scrubbed), `ls -la /usr/local/bin/devin` (SIM, old mtime, root-owned).
  root cause: an older second copy earlier on PATH shadows the updated ~/.local/bin/devin.
  fix: remove the stale copy (or fix PATH order), `hash -r`, verify with `type -a devin`.
  distractors: devin update --force; clear ~/.cache/devin; reinstall with sudo (docs say never sudo).
S7 claude-hook (hooks): ticket "Some hook keeps blocking my commands with 'blocked by policy' but I have no Devin hooks configured."
  cmds: `ls .devin` (SIM: No such file), `cat ~/.config/devin/config.json` (SIM {"version":1}), `ls -la .claude`
  (evidence, SIM settings.json), `cat .claude/settings.json` (evidence, SIM: hooks.PreToolUse with a command echoing
  'blocked by policy' + exit 2), `devin --version` (SIM).
  root cause: Devin imports hooks from .claude/settings.json because read_config_from.claude is on by default.
  fix: remove that hook, or set read_config_from.claude=false in user config; confirm source with /hooks.
  distractors (both q's): org policy; sandbox; corrupted sessions.db; windsurf rules.
S8 mcp-typo (mcp): ticket "My filesystem MCP server's tools never show up in Devin."
  fault: stdio server `fs` with command `npx -y @modelcontextprotocol/server-filesystm /home/customer/docs` (typo).
  cmds: `devin mcp list` (RECORD with that config in temp HOME; evidence only if it shows an error/status), `devin mcp get fs`
  (evidence, RECORD), `cat ~/.config/devin/mcp_config.json` (evidence, RECORD the file the CLI actually wrote — create it
  via `devin mcp add` in temp HOME, not by hand), `npx -y @modelcontextprotocol/server-filesystm /tmp` (evidence, SIM: npm
  E404 'Not Found - GET https://registry.npmjs.org/@modelcontextprotocol%2fserver-filesystm'), `devin --version` (SIM).
  root cause: package name typo, so the stdio server never starts. distractors: org disallows MCP; needs `devin mcp login`; HTTP transport required.
  fix: `devin mcp remove fs` then re-add with the correct package `@modelcontextprotocol/server-filesystem`; verify by running
  the command manually first. distractors: devin mcp enable fs; restart terminal; add mcp__fs__* to allow list.

## Tests (tests/test_dojo.py, unittest, use a temp DOJO_HOME)
- grading: exact, keyword, normalization (quotes/case/whitespace), MC letter + text.
- Leitner transitions + due dates (inject clock).
- selection order (due first, new cap 5, seed determinism).
- scenario engine: regex match, unknown-command message, turn cost, repeat gives no evidence, combo build/reset/cap, scoring math.
- content validation: every json item has required fields, unique ids, MC answer idx in range, all regex compile, every
  scenario's `optimal` commands each match some command entry, and every evidence command is reachable.
- end-to-end: run `dojo.py play --seed 1 --rounds 3 --no-live` with piped stdin answers; exit 0, state.json written.
Lint: `flake8 --max-line-length 120 dojo.py tests/`.
