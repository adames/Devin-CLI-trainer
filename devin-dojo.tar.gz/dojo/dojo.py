#!/usr/bin/env python3
import argparse
import datetime as dt
import json
import math
import os
import random
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent
BOX_INTERVALS = {1: 0, 2: 1, 3: 3, 4: 7, 5: 21}
TITLES = {
    1: "Intern",
    2: "Log Reader",
    3: "Triage Tech",
    4: "Tracer",
    5: "Config Whisperer",
    6: "Root-Causer",
}
KNOWN_COMMANDS = {
    "devin", "cat", "ls", "jq", "rg", "grep", "env", "echo", "type", "which",
    "command", "bash", "curl", "ps", "lsof", "ss", "strace", "tail", "head",
    "find", "sqlite3", "git", "python3", "printenv", "diff",
}


def normalize(value):
    value = str(value).lower().replace("'", "").replace('"', "").replace("`", "")
    return " ".join(value.split())


def normalize_whitespace(value):
    return " ".join(value.split())


def level_for_xp(xp):
    return int(math.sqrt(max(0, xp) / 50)) + 1


def title_for_level(level):
    return TITLES.get(level, "Staff RCA")


def streak_multiplier(streak):
    return min(1 + 0.25 * streak, 3.0)


def levelled_xp(base, global_multiplier):
    return int(round(base * global_multiplier))


def combo_score(evidence_found, unused_turns, best_combo, root_correct, fix_correct):
    base = max(0, 50 + 10 * evidence_found + 5 * unused_turns)
    if not root_correct:
        base = max(0, base - 20)
    if fix_correct:
        base += 25
    return base * max(1, best_combo)


def default_state():
    return {
        "xp": 0,
        "streak": 0,
        "daily_streak": 0,
        "last_session_date": None,
        "sessions": 0,
        "items": {},
    }


def dojo_home():
    configured = os.environ.get("DOJO_HOME")
    return Path(configured).expanduser() if configured else Path.home() / ".devin-dojo"


def load_state(home):
    path = home / "state.json"
    if not path.exists():
        return default_state()
    with path.open(encoding="utf-8") as stream:
        state = json.load(stream)
    base = default_state()
    base.update(state)
    if not isinstance(base.get("items"), dict):
        raise ValueError("state.json items must be an object")
    return base


def save_state(home, state):
    home.mkdir(parents=True, exist_ok=True)
    target = home / "state.json"
    temporary = home / ".state.json.tmp"
    temporary.write_text(json.dumps(state, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(str(temporary), str(target))


def parse_time(value):
    if not value:
        return None
    parsed = dt.datetime.fromisoformat(value)
    if parsed.tzinfo is None:
        return parsed.astimezone()
    return parsed


def review_item(state, item_id, correct, now=None):
    now = now or dt.datetime.now().astimezone()
    items = state.setdefault("items", {})
    progress = items.setdefault(item_id, {"box": 1, "seen": 0, "correct": 0})
    progress["seen"] = progress.get("seen", 0) + 1
    if correct:
        progress["correct"] = progress.get("correct", 0) + 1
        progress["box"] = min(5, progress.get("box", 1) + 1)
        days = BOX_INTERVALS[progress["box"]]
        progress["due"] = (now + dt.timedelta(days=days)).isoformat()
    else:
        progress["box"] = 1
        progress["due"] = now.isoformat()
    progress["last_seen"] = now.isoformat()
    return progress


def select_item(items, state, new_seen, rng, now=None, played=None):
    now = now or dt.datetime.now().astimezone()
    played = set() if played is None else played
    progress_by_id = state.get("items", {})
    shuffled = list(items)
    rng.shuffle(shuffled)

    due = []
    new = []
    not_due = []
    for item in shuffled:
        if item["id"] in played:
            continue
        progress = progress_by_id.get(item["id"])
        if progress is None:
            new.append(item)
            continue
        due_date = parse_time(progress.get("due"))
        if due_date is None or due_date <= now:
            due.append((due_date or now, item))
        else:
            not_due.append((progress.get("box", 1), due_date, item))
    if due:
        due.sort(key=lambda pair: pair[0])
        return due[0][1]
    if len(new_seen) < 5 and new:
        return new[0]
    if not_due:
        not_due.sort(key=lambda row: (row[0], row[1]))
        return not_due[0][2]
    if new:
        return new[0]
    return None


def grade_answer(item, response, displayed_choices=None):
    candidate = response
    if displayed_choices and len(response.strip()) == 1:
        letter = response.strip().lower()
        if letter in "abcd":
            index = ord(letter) - ord("a")
            if index < len(displayed_choices):
                candidate = displayed_choices[index]
    candidate_normalized = normalize(candidate)
    answers = [normalize(value) for value in item.get("answers", [])]
    if candidate_normalized in answers:
        return True
    return all(
        normalize(keyword) in candidate_normalized
        for keyword in item.get("keywords", [])
    )


def load_json_items(path):
    with path.open(encoding="utf-8") as stream:
        data = json.load(stream)
    if isinstance(data, list):
        return data
    if isinstance(data, dict) and "id" in data:
        return [data]
    if isinstance(data, dict):
        result = []
        for value in data.values():
            if isinstance(value, list):
                result.extend(value)
            elif isinstance(value, dict) and "id" in value:
                result.append(value)
        return result
    raise ValueError("%s must contain an item or a list of items" % path)


def load_content(home):
    content = {
        "flash": load_json_items(BASE_DIR / "content" / "cards.json"),
        "drill": load_json_items(BASE_DIR / "content" / "drills.json"),
        "combo": load_json_items(BASE_DIR / "content" / "scenarios.json"),
    }
    custom_dir = home / "content"
    if custom_dir.exists():
        for path in sorted(custom_dir.glob("*.json")):
            for item in load_json_items(path):
                if "root_cause" in item:
                    content["combo"].append(item)
                elif "kind" in item:
                    content["drill"].append(item)
                else:
                    content["flash"].append(item)
    return content


def validate_content(content):
    ids = set()
    topics = {
        "launch", "sessions", "auth", "config", "permissions", "modes", "slash",
        "cloud", "hooks", "rules", "skills", "mcp", "logs", "debug", "acp", "general-cli",
    }
    required_flash = {"id", "topic", "q", "answers", "keywords", "hint", "explain"}
    required_drill = {
        "id", "topic", "prompt", "platforms", "requires", "costs_credits",
        "setup", "kind", "cleanup", "explain",
    }
    required_scenario = {
        "id", "topic", "title", "ticket", "prompt", "turns", "commands",
        "unknown_output", "root_cause", "fix", "optimal", "explain",
    }
    for category, items, required in (
        ("flash", content["flash"], required_flash),
        ("drill", content["drill"], required_drill),
        ("combo", content["combo"], required_scenario),
    ):
        for item in items:
            missing = required - set(item)
            if missing:
                raise ValueError("%s %s is missing %s" % (category, item.get("id"), sorted(missing)))
            if item["id"] in ids:
                raise ValueError("duplicate content id: %s" % item["id"])
            if item["topic"] not in topics:
                raise ValueError("invalid topic %r in %s" % (item["topic"], item["id"]))
            ids.add(item["id"])
            if category == "flash" and (
                not isinstance(item["answers"], list)
                or not item["answers"]
                or not isinstance(item["keywords"], list)
            ):
                raise ValueError("invalid flash answers or keywords: %s" % item["id"])
            if category == "flash" and "choices" in item:
                if len(item["choices"]) != 4 or item["answers"][0] not in item["choices"]:
                    raise ValueError("invalid multiple-choice answers: %s" % item["id"])
            if category == "drill":
                if item["kind"] not in ("answer", "check"):
                    raise ValueError("invalid drill kind: %s" % item["id"])
                if item["kind"] == "answer" and "truth" not in item:
                    raise ValueError("answer drill has no truth command: %s" % item["id"])
                if item["kind"] == "check" and "check" not in item:
                    raise ValueError("check drill has no check command: %s" % item["id"])
            if category == "combo":
                if not isinstance(item["turns"], int) or item["turns"] < 1:
                    raise ValueError("invalid turn count: %s" % item["id"])
                for question in ("root_cause", "fix"):
                    choices = item[question].get("choices", [])
                    answer = item[question].get("answer")
                    if len(choices) != 4 or type(answer) is not int or not 0 <= answer < len(choices):
                        raise ValueError("invalid %s answer index: %s" % (question, item["id"]))
                patterns = []
                command_ids = set()
                for command in item["commands"]:
                    missing_command = {"id", "match", "output", "evidence", "source"} - set(command)
                    if missing_command:
                        raise ValueError(
                            "scenario command in %s is missing %s" %
                            (item["id"], sorted(missing_command))
                        )
                    if command["id"] in command_ids:
                        raise ValueError("duplicate command id in %s: %s" % (item["id"], command["id"]))
                    if command["source"] not in ("recorded", "simulated"):
                        raise ValueError("invalid command source in %s: %s" % (item["id"], command["id"]))
                    if not isinstance(command["evidence"], bool):
                        raise ValueError("invalid evidence flag in %s: %s" % (item["id"], command["id"]))
                    command_ids.add(command["id"])
                    if not command.get("match"):
                        raise ValueError("command has no match patterns: %s" % item["id"])
                    for pattern in command["match"]:
                        patterns.append(re.compile(pattern, re.IGNORECASE))
                for optimal in item["optimal"]:
                    command = normalize_whitespace(optimal)
                    if not any(pattern.fullmatch(command) for pattern in patterns):
                        raise ValueError("unmatched optimal command %r in %s" % (optimal, item["id"]))
    return True


def color(text, code):
    if os.environ.get("NO_COLOR") is not None or not sys.stdout.isatty():
        return text
    return "\033[%sm%s\033[0m" % (code, text)


def command_environment(arena):
    env = os.environ.copy()
    env.pop("DEVIN_DESKTOP_AUTH_TOKEN", None)
    local_bin = str(Path.home() / ".local" / "bin")
    path_parts = env.get("PATH", "").split(os.pathsep)
    if local_bin not in path_parts:
        env["PATH"] = local_bin + os.pathsep + env.get("PATH", "")
    env["DOJO_ARENA"] = str(arena)
    return env


def run_shell(command, arena, timeout=30):
    try:
        return subprocess.run(
            command,
            shell=True,
            cwd=str(arena),
            env=command_environment(arena),
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired as error:
        output = error.stdout or ""
        stderr = error.stderr or ""
        if isinstance(output, bytes):
            output = output.decode(errors="replace")
        if isinstance(stderr, bytes):
            stderr = stderr.decode(errors="replace")
        return subprocess.CompletedProcess(command, 124, output, stderr + "\ncommand timed out")


def print_process_output(result):
    output = (result.stdout or "") + (result.stderr or "")
    if output:
        print(output.rstrip("\n"))
    if result.returncode:
        print("[exit code %s]" % result.returncode)


def parse_choice(value, choices, displayed_choices=None):
    candidate = value.strip()
    if len(candidate) == 1 and candidate.lower() in "abcd":
        index = ord(candidate.lower()) - ord("a")
        if displayed_choices is not None and index < len(displayed_choices):
            text = displayed_choices[index]
            return next((i for i, choice in enumerate(choices) if normalize(choice) == normalize(text)), None)
    if candidate.isdigit():
        index = int(candidate) - 1
        if 0 <= index < len(choices):
            return index
    return next((i for i, choice in enumerate(choices) if normalize(choice) == normalize(candidate)), None)


class Dojo:
    def __init__(self, home, content):
        self.home = home
        self.arena_root = home / "arena"
        self.state = load_state(home)
        self.content = content
        self.rng = random.Random()
        self.new_seen = set()
        self.session_seen = []
        self.session_missed = []
        self.topic_totals = {}
        self.session_xp = 0
        self.best_combo = 1
        self.flash_rounds = 0
        self.flash_requeues = {}
        self.requeued = set()
        self.played = set()
        self.last_flash_id = None
        self.auth_status = None
        self.stop_requested = False
        self.round_attempts = 0
        self.round_correct = 0

    def award(self, points):
        old_xp = self.state.get("xp", 0)
        self.state["xp"] = max(0, old_xp + points)
        actual = self.state["xp"] - old_xp
        self.session_xp += actual
        return actual

    def begin_session(self, seed=None):
        if seed is not None:
            self.rng.seed(seed)
        self.new_seen.clear()
        self.played.clear()
        self.flash_rounds = 0
        self.flash_requeues.clear()
        self.requeued.clear()
        self.last_flash_id = None
        self.stop_requested = False
        today = dt.date.today()
        previous = self.state.get("last_session_date")
        if previous == today.isoformat():
            pass
        elif previous:
            previous_date = dt.date.fromisoformat(previous)
            self.state["daily_streak"] = (
                self.state.get("daily_streak", 0) + 1
                if previous_date == today - dt.timedelta(days=1)
                else 1
            )
        else:
            self.state["daily_streak"] = 1
        self.state["last_session_date"] = today.isoformat()
        self.state["sessions"] = self.state.get("sessions", 0) + 1

    def record_round(self, item, correct):
        self.round_attempts += 1
        if correct:
            self.round_correct += 1
        topic = item["topic"]
        total = self.topic_totals.setdefault(topic, [0, 0])
        total[0] += int(bool(correct))
        total[1] += 1
        progress = review_item(self.state, item["id"], correct)
        progress["topic"] = topic
        self.session_seen.append(item)
        if not correct:
            self.session_missed.append(item)

    def global_multiplier(self):
        return streak_multiplier(self.state.get("streak", 0))

    def resolve_streak(self, correct):
        self.state["streak"] = self.state.get("streak", 0) + 1 if correct else 0

    def header(self, item, category, round_number, total_rounds):
        level = level_for_xp(self.state.get("xp", 0))
        multiplier = self.global_multiplier()
        line = "[L%d %s | %dxp | streak x%.2f | round %d/%d | %s:%s]" % (
            level,
            title_for_level(level),
            self.state.get("xp", 0),
            multiplier,
            round_number,
            total_rounds,
            category,
            item["topic"],
        )
        print(color(line, "36"))

    def eligible_drills(self, topic_filter, no_live, allow_credits):
        if no_live:
            return []
        platform = "darwin" if sys.platform == "darwin" else "linux" if sys.platform.startswith("linux") else "win32"
        eligible = []
        for drill in self.content["drill"]:
            if topic_filter and not topic_filter.search(drill["topic"]):
                continue
            if platform not in drill["platforms"]:
                continue
            if drill.get("costs_credits") and not allow_credits:
                continue
            missing = False
            for requirement in drill.get("requires", []):
                if requirement == "auth":
                    if self.auth_status is None:
                        self.auth_status = self.query_auth_status()
                    if "Not logged in" in self.auth_status:
                        missing = True
                        break
                elif shutil.which(requirement) is None:
                    missing = True
                    break
            if not missing:
                eligible.append(drill)
        return eligible

    @staticmethod
    def query_auth_status():
        try:
            result = subprocess.run(
                ["devin", "auth", "status"],
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                env=command_environment(Path.cwd()),
                timeout=10,
            )
            return result.stdout or ""
        except (OSError, subprocess.TimeoutExpired):
            return "Not logged in."

    def choose_item(self, category, items):
        ready = []
        if category == "flash":
            self.flash_rounds += 1
            for item in items:
                ready_after = self.flash_requeues.get(item["id"])
                if ready_after is not None and ready_after <= self.flash_rounds:
                    ready.append(item)
            if ready:
                item = min(ready, key=lambda candidate: self.flash_requeues[candidate["id"]])
                del self.flash_requeues[item["id"]]
                self.played.add(item["id"])
                self.last_flash_id = item["id"]
                return item
        item = select_item(
            items,
            self.state,
            self.new_seen,
            self.rng,
            played=self.played,
        )
        if item is None and category == "flash" and self.flash_requeues:
            pending = [
                (ready_after, candidate)
                for candidate in items
                for ready_after in [self.flash_requeues.get(candidate["id"])]
                if ready_after is not None and candidate["id"] != self.last_flash_id
            ]
            if pending:
                item = min(pending, key=lambda pair: pair[0])[1]
                del self.flash_requeues[item["id"]]
        if item is not None:
            self.played.add(item["id"])
            if category == "flash":
                self.last_flash_id = item["id"]
        return item

    def make_arena(self, drill):
        arena = self.arena_root / drill["id"]
        if arena.exists():
            shutil.rmtree(str(arena))
        arena.mkdir(parents=True)
        return arena

    def run_drill(self, drill):
        arena = self.make_arena(drill)
        correct = False
        quit_game = False
        resolved = False
        try:
            for command in drill.get("setup", []):
                result = run_shell(command, arena)
                print_process_output(result)
                if result.returncode:
                    print("Setup command failed.")
            started = time.monotonic()
            print(drill["prompt"])
            print("Use !command to run a shell command; type 'give up' to stop this drill.")
            while True:
                answer = input(">> ")
                if answer.strip().lower().startswith("!"):
                    command = answer.strip()[1:].strip()
                    if command:
                        print_process_output(run_shell(command, arena))
                    continue
                if answer.strip().lower() == "quit":
                    quit_game = True
                    return None, quit_game
                if answer.strip().lower() == "give up":
                    print(drill["explain"])
                    self.record_round(drill, False)
                    resolved = True
                    break
                if drill["kind"] == "check" and answer.strip():
                    print("Press Enter when your check is ready.")
                    continue
                elapsed = time.monotonic() - started
                expected = None
                if drill["kind"] == "answer":
                    expected = run_shell(drill["truth"], arena).stdout.strip()
                    correct = normalize(answer) == normalize(expected)
                else:
                    result = run_shell(drill["check"], arena)
                    print_process_output(result)
                    correct = result.returncode == 0
                if correct:
                    bonus = max(0, 15 - int(elapsed // 20))
                    print(color("Drill passed.", "32"))
                    self.record_round(drill, True)
                    base = 25 + bonus
                    self.award(levelled_xp(base, self.global_multiplier()))
                else:
                    print("Expected: %s" % (
                        expected if drill["kind"] == "answer"
                        else drill["explain"]
                    ))
                    print(drill["explain"])
                    self.record_round(drill, False)
                resolved = True
                break
        finally:
            cleanup = drill.get("cleanup", [])
            for command in cleanup:
                result = run_shell(command, arena)
                print_process_output(result)
            print("Cleanup completed.")
        if resolved and not quit_game:
            self.resolve_streak(correct)
        return correct, quit_game

    def play_flash(self, item):
        displayed_choices = None
        if item.get("choices"):
            displayed_choices = list(item["choices"])
            self.rng.shuffle(displayed_choices)
        print(item["q"])
        if displayed_choices:
            for index, choice in enumerate(displayed_choices):
                print("%s) %s" % (chr(ord("a") + index), choice))
        hint_used = False
        while True:
            response = input("Answer (? for hint, skip, or quit): ")
            stripped = response.strip()
            if stripped.lower() == "quit":
                return None
            if stripped == "?":
                if not hint_used:
                    print("Hint: %s" % item["hint"])
                    hint_used = True
                else:
                    print("Hint already used.")
                continue
            if stripped.lower() == "skip":
                answer = item.get("answers", [""])[0]
                print("Answer: %s" % answer)
                print(item["explain"])
                correct = False
                self_graded = False
                break
            correct = grade_answer(item, response, displayed_choices)
            if correct:
                self_graded = False
                break
            answer = item.get("answers", [""])[0]
            print("Answer: %s" % answer)
            print(item["explain"])
            count_it = input("Count it? [y/N] ")
            if count_it.strip().lower() == "y":
                correct = True
                self_graded = True
            else:
                self_graded = False
            break
        if correct:
            print(color("Correct.", "32"))
            base = 5 if hint_used or self_graded else 10
        else:
            print(color("Not this time.", "31"))
            base = 0
        self.record_round(item, correct)
        if not correct and item["id"] not in self.requeued:
            self.requeued.add(item["id"])
            self.flash_requeues[item["id"]] = self.flash_rounds + 3
        self.award(levelled_xp(base, self.global_multiplier()))
        self.resolve_streak(correct)
        return correct

    def match_scenario_command(self, scenario, command):
        normalized = normalize_whitespace(command)
        for entry in scenario["commands"]:
            for pattern in entry["match"]:
                if re.fullmatch(pattern, normalized, re.IGNORECASE):
                    return entry
        return None

    def run_combo_command(self, scenario, command, engine_state):
        entry = self.match_scenario_command(scenario, command)
        engine_state["turns_used"] += 1
        if entry is None:
            token = command.strip().split(maxsplit=1)[0] if command.strip() else ""
            if token and token not in KNOWN_COMMANDS:
                output = "bash: %s: command not found" % token
            else:
                output = scenario["unknown_output"]
            engine_state["evidence_streak"] = 0
            return output, False
        output = entry["output"]
        if entry.get("source") == "simulated":
            output += color(" [sim]", "2")
        is_new = entry["id"] not in engine_state["run_ids"]
        engine_state["run_ids"].add(entry["id"])
        evidence = bool(entry.get("evidence")) and is_new
        if evidence:
            engine_state["evidence_ids"].add(entry["id"])
            engine_state["evidence_streak"] = min(3, engine_state["evidence_streak"] + 1)
            engine_state["best_combo"] = max(
                engine_state["best_combo"], engine_state["evidence_streak"]
            )
        else:
            engine_state["evidence_streak"] = 0
        return output, evidence

    def next_hint(self, scenario, engine_state):
        for optimal in scenario["optimal"]:
            entry = self.match_scenario_command(scenario, optimal)
            if entry is None or entry["id"] not in engine_state["run_ids"]:
                return optimal
        return scenario["optimal"][-1] if scenario["optimal"] else ""

    def ask_scenario_question(self, question):
        choices = question["choices"]
        for index, choice in enumerate(choices):
            print("%d) %s" % (index + 1, choice))
        while True:
            response = input("Choose 1-4 (or type the answer): ")
            selected = parse_choice(response, choices)
            if selected is not None:
                return selected
            print("Choose one of the listed answers.")

    def play_combo(self, scenario):
        print("MYSTERY TICKET: %s" % scenario["title"])
        print(scenario["ticket"])
        state = {
            "turns_used": 0,
            "run_ids": set(),
            "evidence_ids": set(),
            "evidence_streak": 0,
            "best_combo": 1,
        }
        print("%s" % scenario["prompt"])
        solve = False
        while state["turns_used"] < scenario["turns"]:
            command = input(scenario["prompt"])
            lowered = command.strip().lower()
            if lowered == "ticket":
                print(scenario["ticket"])
                continue
            if lowered == "hint":
                print("Next optimal command: %s" % self.next_hint(scenario, state))
                self.award(-10)
                continue
            if lowered == "solve":
                solve = True
                break
            if lowered == "quit":
                self.stop_requested = True
                return None
            output, evidence = self.run_combo_command(scenario, command, state)
            if output:
                print(output)
            if evidence:
                print("Evidence found (%d/%d)." % (
                    len(state["evidence_ids"]),
                    sum(bool(entry.get("evidence")) for entry in scenario["commands"]),
                ))
            print("Turns: %d/%d | combo x%d" % (
                state["turns_used"], scenario["turns"], state["evidence_streak"]
            ))
        if not solve:
            print("Out of turns; solve the ticket.")
        print("Root cause: %s" % scenario["root_cause"]["q"])
        root_index = self.ask_scenario_question(scenario["root_cause"])
        root_correct = root_index == scenario["root_cause"]["answer"]
        if not root_correct:
            print("Wrong root-cause guess (-20 XP).")
        print("Fix: %s" % scenario["fix"]["q"])
        fix_index = self.ask_scenario_question(scenario["fix"])
        fix_correct = fix_index == scenario["fix"]["answer"]
        if root_correct:
            print("Root cause correct.")
        if fix_correct:
            print("Fix correct (+25 XP).")
        print("Correct root cause: %s" % scenario["root_cause"]["choices"][scenario["root_cause"]["answer"]])
        print("Correct fix: %s" % scenario["fix"]["choices"][scenario["fix"]["answer"]])
        print("Optimal chain: %s" % " -> ".join(scenario["optimal"]))
        print(scenario["explain"])
        evidence_total = sum(bool(entry.get("evidence")) for entry in scenario["commands"])
        print("Evidence found %d/%d." % (len(state["evidence_ids"]), evidence_total))
        self.best_combo = max(self.best_combo, state["best_combo"])
        self.record_round(scenario, root_correct)
        round_points = combo_score(
            len(state["evidence_ids"]),
            scenario["turns"] - state["turns_used"],
            state["best_combo"],
            root_correct,
            fix_correct,
        )
        self.award(levelled_xp(round_points, self.global_multiplier()))
        self.resolve_streak(root_correct)
        return root_correct

    def play(self, mode=None, topic=None, rounds=None, seed=None, no_live=False, allow_credits=False):
        try:
            topic_filter = re.compile(topic, re.IGNORECASE) if topic else None
        except re.error as error:
            raise ValueError("invalid topic regex: %s" % error)
        self.begin_session(seed)
        flash = [
            item for item in self.content["flash"]
            if not topic_filter or topic_filter.search(item["topic"])
        ]
        combos = [
            item for item in self.content["combo"]
            if not topic_filter or topic_filter.search(item["topic"])
        ]
        if mode == "flash":
            plan = ["flash"] * 6
        elif mode == "drill":
            plan = ["drill"] * 2
        elif mode == "combo":
            plan = ["combo"]
        else:
            plan = ["flash"] * 6 + ["drill"] * 2 + ["flash"] * 4 + ["combo"]
        if rounds is not None:
            plan = plan[:rounds]
        drills = (
            self.eligible_drills(topic_filter, no_live, allow_credits)
            if "drill" in plan else []
        )
        total = len(plan)
        try:
            for round_number, requested in enumerate(plan, 1):
                if self.stop_requested:
                    break
                options = {"flash": flash, "drill": drills, "combo": combos}[requested]
                category = requested if options else "flash"
                item = self.choose_item(category, options if options else flash)
                if item is None:
                    print("No eligible %s items; ending session." % category)
                    break
                self.new_seen.add(item["id"])
                self.header(item, category, round_number, total)
                if category == "flash":
                    result = self.play_flash(item)
                    if result is None:
                        self.stop_requested = True
                elif category == "drill":
                    _, quit_game = self.run_drill(item)
                    if quit_game:
                        self.stop_requested = True
                else:
                    self.play_combo(item)
        except EOFError:
            print("\nInput ended; saving progress.")
        except KeyboardInterrupt:
            print("\nInterrupted; saving progress.")
        self.print_summary()
        save_state(self.home, self.state)

    def print_summary(self):
        accuracy = (
            100 * self.round_correct / self.round_attempts
            if self.round_attempts
            else 0
        )
        print("\nSession summary")
        print("XP gained: %d" % self.session_xp)
        print("Accuracy: %d/%d (%.1f%%)" % (
            self.round_correct, self.round_attempts, accuracy
        ))
        if self.topic_totals:
            print("Per-topic accuracy:")
            for topic in sorted(self.topic_totals):
                correct, seen = self.topic_totals[topic]
                print("  %s: %d/%d (%.1f%%)" % (
                    topic, correct, seen, 100 * correct / seen
                ))
            weakest = sorted(
                (
                    (topic, totals)
                    for topic, totals in self.topic_totals.items()
                    if totals[0] < totals[1]
                ),
                key=lambda pair: (pair[1][0] / pair[1][1], pair[0]),
            )[:3]
            if weakest:
                print("Weakest topics: %s" % ", ".join(topic for topic, _ in weakest))
            else:
                print("Weakest topics: none")
        if self.session_missed:
            print("Missed items:")
            for item in self.session_missed:
                if "root_cause" in item:
                    question = item["root_cause"]["q"]
                    answer = item["root_cause"]["choices"][item["root_cause"]["answer"]]
                else:
                    question = item.get("q", item.get("prompt", item.get("ticket", item["id"])))
                    answer = item.get("answers", [item.get("explain", "")])[0]
                print("  %s -> %s" % (question, answer))
        now = dt.datetime.now().astimezone()
        tomorrow = now + dt.timedelta(days=1)
        due_tomorrow = []
        for item_id, progress in self.state.get("items", {}).items():
            due = parse_time(progress.get("due"))
            if due and due.date() == tomorrow.date():
                due_tomorrow.append(item_id)
        print("Items due tomorrow: %d" % len(due_tomorrow))
        print("Best combo: x%d" % self.best_combo)


def show_stats(state):
    level = level_for_xp(state.get("xp", 0))
    print("Level: L%d %s" % (level, title_for_level(level)))
    print("XP: %d | streak: %d | daily streak: %d" % (
        state.get("xp", 0),
        state.get("streak", 0),
        state.get("daily_streak", 0),
    ))
    items = state.get("items", {})
    seen = sum(progress.get("seen", 0) for progress in items.values())
    correct = sum(progress.get("correct", 0) for progress in items.values())
    percent = 100 * correct / seen if seen else 0
    print("Accuracy: %d/%d (%.1f%%)" % (correct, seen, percent))
    now = dt.datetime.now().astimezone()
    boxes = {box: 0 for box in range(1, 6)}
    due_today = 0
    for progress in items.values():
        box = progress.get("box", 1)
        boxes[box] = boxes.get(box, 0) + 1
        due = parse_time(progress.get("due"))
        if due and due.date() <= now.date():
            due_today += 1
    print("Leitner boxes: %s" % ", ".join(
        "box %d: %d" % (box, boxes[box]) for box in range(1, 6)
    ))
    print("Due today: %d" % due_today)
    topics = {}
    for item_id, progress in items.items():
        topic = progress.get("topic", "unknown")
        total = topics.setdefault(topic, [0, 0])
        total[0] += progress.get("correct", 0)
        total[1] += progress.get("seen", 0)
    if topics:
        print("Accuracy by topic:")
        for topic in sorted(topics):
            count, total = topics[topic]
            percent = 100 * count / total if total else 0
            print("  %s: %d/%d (%.1f%%)" % (topic, count, total, percent))


def list_items(content, state, item_type=None):
    labels = (("flash", "flash"), ("drill", "drill"), ("combo", "combo"))
    for category, key in labels:
        if item_type and item_type != category:
            continue
        print("%s items:" % category.title())
        for item in content[key]:
            progress = state.get("items", {}).get(item["id"], {})
            print("%s\t%s\tbox %d" % (
                item["id"], item["topic"], progress.get("box", 1)
            ))


def ask_reset():
    try:
        return input("Reset all dojo progress? [y/N] ").strip().lower() == "y"
    except EOFError:
        return False


def add_play_arguments(parser):
    parser.add_argument("--mode", choices=("flash", "drill", "combo"))
    parser.add_argument("--topic")
    parser.add_argument("--rounds", type=int)
    parser.add_argument("--seed", type=int)
    parser.add_argument("--no-live", action="store_true")
    parser.add_argument("--allow-credits", action="store_true")


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    commands = {"play", "stats", "list", "reset"}
    if argv and argv[0] in commands:
        parser = argparse.ArgumentParser(prog="dojo.py")
        subparsers = parser.add_subparsers(dest="command", required=True)
        play_parser = subparsers.add_parser("play")
        add_play_arguments(play_parser)
        stats_parser = subparsers.add_parser("stats")
        stats_parser.set_defaults(command="stats")
        list_parser = subparsers.add_parser("list")
        list_parser.add_argument("--type", choices=("flash", "drill", "combo"))
        reset_parser = subparsers.add_parser("reset")
        reset_parser.add_argument("--yes", action="store_true")
        args = parser.parse_args(argv)
    else:
        parser = argparse.ArgumentParser(prog="dojo.py")
        add_play_arguments(parser)
        args = parser.parse_args(argv)
        args.command = "play"

    home = dojo_home()
    try:
        content = load_content(home)
        validate_content(content)
        state = load_state(home)
        if args.command == "stats":
            show_stats(state)
        elif args.command == "list":
            list_items(content, state, getattr(args, "type", None))
        elif args.command == "reset":
            if args.yes or ask_reset():
                save_state(home, default_state())
                print("Progress reset.")
            else:
                print("Reset cancelled.")
        else:
            if args.rounds is not None and args.rounds < 1:
                raise ValueError("--rounds must be at least 1")
            game = Dojo(home, content)
            game.play(
                mode=args.mode,
                topic=args.topic,
                rounds=args.rounds,
                seed=args.seed,
                no_live=args.no_live,
                allow_credits=args.allow_credits,
            )
    except EOFError:
        print("\nInput ended; saving progress.")
    except KeyboardInterrupt:
        print("\nInterrupted; saving progress.")
        save_state(home, load_state(home))
    except (OSError, ValueError, json.JSONDecodeError) as error:
        print("dojo: %s" % error, file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
